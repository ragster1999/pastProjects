//Letter.h

struct Letter{
    char guess; // A char to store the letter
    bool fresh; // To see if it's a fresh (new) guess or not
};